"""
Generic Data Quality Checks
───────────────────────────
Unlike the original standalone version (which hardcoded Postgres + Snowflake
credentials and a fixed 4-table list), these checks run against ANY
connection already saved in `saved_connections`, using the project's
existing `sql_executors` abstraction (sql_executors.get_executor).

Every check function takes a live BaseSqlExecutor instance and returns a
plain dict matching the `quality_results` table columns, so the router can
insert results directly without any extra mapping.
"""

import re
from typing import Any, Dict, List, Optional

from sql_executors.base import BaseSqlExecutor

# Only allow simple identifiers (letters, numbers, underscore, dot for
# schema.table). Table/column names always come from the platform's own
# schema-introspection endpoints or from values the user typed into a
# "table name" field — never from raw free-text — but we validate anyway
# since these values get interpolated into SQL text.
_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9_.]+$")


def _safe_identifier(name: str) -> str:
    if not _IDENTIFIER_RE.match(name):
        raise ValueError(f"Unsafe identifier rejected: {name!r}")
    return name


async def _scalar(executor: BaseSqlExecutor, query: str) -> Any:
    result = await executor.execute(query, limit=1, timeout_seconds=30)
    if not result.rows:
        return None
    return result.rows[0][0]


def _result(table_name, check_name, status, failed_rows=0,
            source_value=None, target_value=None, message=""):
    return {
        "table_name": table_name,
        "check_name": check_name,
        "status": status,
        "failed_rows": failed_rows,
        "source_value": source_value,
        "target_value": target_value,
        "message": message,
    }


# ─────────────────────────────────────────────────────────────────────────
# Row count
# ─────────────────────────────────────────────────────────────────────────
async def run_row_count_check(
    executor: BaseSqlExecutor,
    table_name: str,
    expected_min_rows: Optional[int] = None,
) -> Dict[str, Any]:
    table = _safe_identifier(table_name)
    count = await _scalar(executor, f"SELECT COUNT(*) FROM {table}")

    if expected_min_rows is None:
        # Informational only — no threshold given, so we can't fail it.
        return _result(table_name, "ROW_COUNT", "PASS",
                        source_value=count,
                        message=f"{table_name} has {count} rows")

    status = "PASS" if count >= expected_min_rows else "FAIL"
    return _result(
        table_name, "ROW_COUNT", status,
        failed_rows=0 if status == "PASS" else expected_min_rows - count,
        source_value=count, target_value=expected_min_rows,
        message=f"{table_name}: {count} rows (expected >= {expected_min_rows})",
    )


# ─────────────────────────────────────────────────────────────────────────
# Null check
# ─────────────────────────────────────────────────────────────────────────
async def run_null_check(
    executor: BaseSqlExecutor,
    table_name: str,
    columns: List[str],
) -> List[Dict[str, Any]]:
    table = _safe_identifier(table_name)
    results = []
    for col in columns:
        column = _safe_identifier(col)
        null_count = await _scalar(
            executor, f"SELECT COUNT(*) FROM {table} WHERE {column} IS NULL"
        )
        status = "PASS" if null_count == 0 else "FAIL"
        results.append(_result(
            table_name, f"NULL_CHECK[{col}]", status,
            failed_rows=null_count,
            message=f"{col}: {null_count} NULL value(s)",
        ))
    return results


# ─────────────────────────────────────────────────────────────────────────
# Duplicate check (based on primary key columns)
# ─────────────────────────────────────────────────────────────────────────
async def run_duplicate_check(
    executor: BaseSqlExecutor,
    table_name: str,
    primary_key: List[str],
) -> Dict[str, Any]:
    table = _safe_identifier(table_name)
    key_columns = ", ".join(_safe_identifier(c) for c in primary_key)

    dup_count = await _scalar(executor, f"""
        SELECT COUNT(*) FROM (
            SELECT {key_columns} FROM {table}
            GROUP BY {key_columns}
            HAVING COUNT(*) > 1
        ) dup
    """)
    status = "PASS" if dup_count == 0 else "FAIL"
    return _result(
        table_name, "DUPLICATE_CHECK", status,
        failed_rows=dup_count,
        message=f"{dup_count} duplicate group(s) on ({key_columns})",
    )


# ─────────────────────────────────────────────────────────────────────────
# Business rule check — a boolean SQL condition that SHOULD MATCH ZERO rows
# e.g. condition="price <= 0"  → any row matching this is a violation
# ─────────────────────────────────────────────────────────────────────────
async def run_business_rule_check(
    executor: BaseSqlExecutor,
    table_name: str,
    column: str,
    condition: str,
) -> Dict[str, Any]:
    table = _safe_identifier(table_name)
    # `condition` is a boolean SQL expression (e.g. "price <= 0"), not a bare
    # identifier, so we don't run it through _safe_identifier. It must come
    # from a trusted, admin-defined rule set (see router.py), never from
    # free-text user input, since it is interpolated directly into SQL.
    violations = await _scalar(
        executor, f"SELECT COUNT(*) FROM {table} WHERE {condition}"
    )
    status = "PASS" if violations == 0 else "FAIL"
    return _result(
        table_name, f"BUSINESS_RULE[{column}]", status,
        failed_rows=violations,
        message=f"Rule '{condition}': {violations} violation(s)",
    )


# ─────────────────────────────────────────────────────────────────────────
# Freshness check
# ─────────────────────────────────────────────────────────────────────────
async def run_freshness_check(
    executor: BaseSqlExecutor,
    table_name: str,
    timestamp_column: str,
    threshold_hours: float,
) -> Dict[str, Any]:
    table = _safe_identifier(table_name)
    column = _safe_identifier(timestamp_column)

    age_hours = await _scalar(executor, f"""
        SELECT EXTRACT(EPOCH FROM (now() - MAX({column}))) / 3600.0
        FROM {table}
    """)

    if age_hours is None:
        return _result(table_name, "FRESHNESS_CHECK", "FAIL",
                        message=f"No rows found in {table_name}")

    status = "PASS" if age_hours <= threshold_hours else "FAIL"
    return _result(
        table_name, "FRESHNESS_CHECK", status,
        source_value=round(float(age_hours), 2), target_value=threshold_hours,
        message=f"Last update {round(float(age_hours), 1)}h ago (threshold {threshold_hours}h)",
    )


# ─────────────────────────────────────────────────────────────────────────
# Referential integrity — child rows whose FK value has no matching parent
# ─────────────────────────────────────────────────────────────────────────
async def run_referential_integrity_check(
    executor: BaseSqlExecutor,
    child_table: str,
    child_column: str,
    parent_table: str,
    parent_column: str,
) -> Dict[str, Any]:
    child = _safe_identifier(child_table)
    child_col = _safe_identifier(child_column)
    parent = _safe_identifier(parent_table)
    parent_col = _safe_identifier(parent_column)

    orphans = await _scalar(executor, f"""
        SELECT COUNT(*) FROM {child} c
        WHERE c.{child_col} IS NOT NULL
          AND NOT EXISTS (
              SELECT 1 FROM {parent} p WHERE p.{parent_col} = c.{child_col}
          )
    """)
    status = "PASS" if orphans == 0 else "FAIL"
    return _result(
        child_table, f"REFERENTIAL_INTEGRITY[{child_column}->{parent_table}.{parent_column}]",
        status, failed_rows=orphans,
        message=f"{orphans} orphan row(s) in {child_table}.{child_column}",
    )