"""
Data Quality Router
────────────────────
API surface for the quality layer. Follows the same shape as
text_sql/router.py and data_generator/router.py:

  - reads connections from the existing `saved_connections` table
  - uses sql_executors.get_executor() instead of a hand-rolled connector
  - stores its own audit trail in Postgres (quality_runs / quality_results —
    see quality_init.sql), NOT in whichever warehouse is being checked

Endpoints
---------
GET  /quality/connections                 list connections quality checks can run against
POST /quality/run                          run a set of checks, store + return results
GET  /quality/runs                         list past runs (paginated)
GET  /quality/runs/{run_id}                get one run + its individual check results
"""

import os
import json
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

import psycopg2
import psycopg2.extras
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sql_executors import get_executor
from quality import checks

router = APIRouter(prefix="/quality", tags=["Data Quality"])

# ── Postgres connection for the quality module's OWN audit tables ─────────
# Deliberately independent of whichever connection is being *checked* —
# audit history always lives in this app's Postgres, same as pipeline_runs /
# pipeline_metrics elsewhere in the project.
DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "postgres"),
    "database": os.getenv("DB_NAME", "airflow"),
    "user":     os.getenv("DB_USER", "airflow"),
    "password": os.getenv("DB_PASSWORD", "airflow"),
    "port":     os.getenv("DB_PORT", "5432"),
}


def _get_conn():
    return psycopg2.connect(**DB_CONFIG)


def _ensure_tables():
    """Idempotent — matches the CREATE TABLE IF NOT EXISTS pattern used
    everywhere else in this project (see main.py ensure_connections_table)."""
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quality_runs (
            run_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            connection_id    INTEGER NOT NULL REFERENCES saved_connections(id) ON DELETE CASCADE,
            started_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
            completed_at     TIMESTAMPTZ,
            duration_seconds NUMERIC,
            total_checks     INTEGER NOT NULL DEFAULT 0,
            passed_checks    INTEGER NOT NULL DEFAULT 0,
            failed_checks    INTEGER NOT NULL DEFAULT 0,
            status           VARCHAR(20) NOT NULL DEFAULT 'RUNNING'
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quality_results (
            id            SERIAL PRIMARY KEY,
            run_id        UUID NOT NULL REFERENCES quality_runs(run_id) ON DELETE CASCADE,
            table_name    VARCHAR(160) NOT NULL,
            check_name    VARCHAR(80)  NOT NULL,
            status        VARCHAR(10)  NOT NULL,
            failed_rows   INTEGER,
            source_value  TEXT,
            target_value  TEXT,
            message       TEXT,
            checked_at    TIMESTAMPTZ NOT NULL DEFAULT now()
        )
    """)
    conn.commit()
    cur.close()
    conn.close()


# ─────────────────────────────────────────────────────────────────────────
# Request/response models
# ─────────────────────────────────────────────────────────────────────────
class TableCheckSpec(BaseModel):
    table_name: str
    primary_key: Optional[List[str]] = None            # enables duplicate check
    null_columns: Optional[List[str]] = None            # enables null check
    expected_min_rows: Optional[int] = None             # enables row-count threshold
    freshness_column: Optional[str] = None
    freshness_threshold_hours: Optional[float] = None
    business_rules: Optional[List[Dict[str, str]]] = None  # [{"column": "price", "condition": "price <= 0"}]


class RunQualityRequest(BaseModel):
    connection_id: int
    tables: List[TableCheckSpec]


# ─────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────
def _load_connection(connection_id: int) -> Dict[str, Any]:
    conn = _get_conn()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        "SELECT id, name, source_type, config FROM saved_connections WHERE id = %s",
        (connection_id,),
    )
    row = cur.fetchone()
    cur.close()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Connection not found")
    return dict(row)


# ─────────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────────
@router.get("/connections")
def list_quality_connections():
    """Connections that quality checks can be run against — reuses the
    same saved_connections table the rest of the app already uses."""
    conn = _get_conn()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT id, name, source_type FROM saved_connections ORDER BY name")
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    return {"connections": rows}


@router.post("/run")
async def run_quality_checks(request: RunQualityRequest):
    _ensure_tables()
    connection = _load_connection(request.connection_id)
    executor = get_executor(connection["source_type"], connection["config"])

    started_at = datetime.utcnow()
    results: List[Dict[str, Any]] = []

    try:
        for table_spec in request.tables:
            table_name = table_spec.table_name

            if table_spec.expected_min_rows is not None or True:
                # row count is always informative even without a threshold
                results.append(await checks.run_row_count_check(
                    executor, table_name, table_spec.expected_min_rows
                ))

            if table_spec.null_columns:
                results.extend(await checks.run_null_check(
                    executor, table_name, table_spec.null_columns
                ))

            if table_spec.primary_key:
                results.append(await checks.run_duplicate_check(
                    executor, table_name, table_spec.primary_key
                ))

            if table_spec.freshness_column and table_spec.freshness_threshold_hours:
                results.append(await checks.run_freshness_check(
                    executor, table_name, table_spec.freshness_column,
                    table_spec.freshness_threshold_hours,
                ))

            for rule in (table_spec.business_rules or []):
                results.append(await checks.run_business_rule_check(
                    executor, table_name, rule["column"], rule["condition"]
                ))
    finally:
        await executor.close()

    completed_at = datetime.utcnow()
    passed = sum(1 for r in results if r["status"] == "PASS")
    failed = sum(1 for r in results if r["status"] == "FAIL")
    overall_status = "PASS" if failed == 0 else "FAIL"

    # ── persist run + results ──────────────────────────────────────────
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO quality_runs
            (connection_id, started_at, completed_at, duration_seconds,
             total_checks, passed_checks, failed_checks, status)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        RETURNING run_id
    """, (
        request.connection_id, started_at, completed_at,
        (completed_at - started_at).total_seconds(),
        len(results), passed, failed, overall_status,
    ))
    run_id = cur.fetchone()[0]

    for r in results:
        cur.execute("""
            INSERT INTO quality_results
                (run_id, table_name, check_name, status, failed_rows,
                 source_value, target_value, message)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            run_id, r["table_name"], r["check_name"], r["status"],
            r.get("failed_rows"),
            str(r["source_value"]) if r.get("source_value") is not None else None,
            str(r["target_value"]) if r.get("target_value") is not None else None,
            r.get("message", ""),
        ))
    conn.commit()
    cur.close()
    conn.close()

    return {
        "run_id": str(run_id),
        "status": overall_status,
        "total_checks": len(results),
        "passed": passed,
        "failed": failed,
        "results": results,
    }


@router.get("/runs")
def list_quality_runs(limit: int = 20, connection_id: Optional[int] = None):
    _ensure_tables()
    conn = _get_conn()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    if connection_id is not None:
        cur.execute("""
            SELECT r.*, c.name AS connection_name
            FROM quality_runs r JOIN saved_connections c ON c.id = r.connection_id
            WHERE r.connection_id = %s
            ORDER BY r.started_at DESC LIMIT %s
        """, (connection_id, limit))
    else:
        cur.execute("""
            SELECT r.*, c.name AS connection_name
            FROM quality_runs r JOIN saved_connections c ON c.id = r.connection_id
            ORDER BY r.started_at DESC LIMIT %s
        """, (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    return {"runs": rows}


@router.get("/runs/{run_id}")
def get_quality_run(run_id: str):
    _ensure_tables()
    conn = _get_conn()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("SELECT * FROM quality_runs WHERE run_id = %s", (run_id,))
    run = cur.fetchone()
    if not run:
        cur.close()
        conn.close()
        raise HTTPException(status_code=404, detail="Run not found")

    cur.execute(
        "SELECT * FROM quality_results WHERE run_id = %s ORDER BY id", (run_id,)
    )
    results = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    return {"run": dict(run), "results": results}