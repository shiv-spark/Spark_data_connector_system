"""
data_tools.py
Fetches raw data from files, S3-compatible paths, APIs, and pipeline tables.
Each function returns a list of dicts ready for analysis.
"""

import pandas as pd
import psycopg2
import psycopg2.extras
from agent.db import query
from agent.logger import get_logger

logger = get_logger(__name__)


def fetch_pipeline_runs(pipeline_name: str = None, limit: int = 200) -> list[dict]:
    logger.info("fetch_pipeline_runs(pipeline=%s, limit=%d)", pipeline_name, limit)
    if pipeline_name:
        sql = """
            SELECT run_id, connector_name, source, start_time, end_time,
                   status, records_count, error
            FROM pipeline_runs
            WHERE connector_name = %s
            ORDER BY start_time DESC
            LIMIT %s
        """
        return query(sql, [pipeline_name, limit])

    sql = """
        SELECT run_id, connector_name, source, start_time, end_time,
               status, records_count, error
        FROM pipeline_runs
        ORDER BY start_time DESC
        LIMIT %s
    """
    return query(sql, [limit])


def fetch_pipeline_logs(run_id: str = None, limit: int = 500) -> list[dict]:
    logger.info("fetch_pipeline_logs(run_id=%s, limit=%d)", run_id, limit)
    if run_id:
        sql = """
            SELECT id, run_id, log_time, level, message
            FROM pipeline_logs
            WHERE run_id = %s
            ORDER BY log_time DESC
            LIMIT %s
        """
        return query(sql, [run_id, limit])

    sql = """
        SELECT id, run_id, log_time, level, message
        FROM pipeline_logs
        ORDER BY log_time DESC
        LIMIT %s
    """
    return query(sql, [limit])


def fetch_pipeline_metrics(pipeline_name: str = None, table_name: str = None, limit: int = 200) -> list[dict]:
    logger.info("fetch_pipeline_metrics(pipeline=%s, table=%s, limit=%d)", pipeline_name, table_name, limit)
    conditions = []
    params = []

    if pipeline_name:
        conditions.append("(pipeline_id = %s OR connector_type = %s)")
        params.extend([pipeline_name, pipeline_name])
    if table_name:
        conditions.append("table_name = %s")
        params.append(table_name)

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    params.append(limit)

    sql = f"""
        SELECT id, pipeline_id, table_name, rows_inserted, rows_skipped,
               rows_failed, duration_sec, evolved_columns, match_pct,
               file_name, connector_type, option, status, error_message, logged_at
        FROM pipeline_metrics
        {where}
        ORDER BY logged_at DESC
        LIMIT %s
    """
    return query(sql, params)


def fetch_airflow_runs(pipeline_name: str = None, limit: int = 200) -> list[dict]:
    logger.info("fetch_airflow_runs(pipeline=%s, limit=%d)", pipeline_name, limit)
    if pipeline_name:
        sql = """
            SELECT id, dag_id, dag_run_id, pipeline_name, connector_type,
                   file_path, folder_path, sheet_url, api_url, operation,
                   table_name, schedule, status, execution_date,
                   triggered_by, error_message, created_at
            FROM airflow_pipeline_runs
            WHERE pipeline_name = %s
            ORDER BY created_at DESC
            LIMIT %s
        """
        return query(sql, [pipeline_name, limit])

    sql = """
        SELECT id, dag_id, dag_run_id, pipeline_name, connector_type,
               file_path, folder_path, sheet_url, api_url, operation,
               table_name, schedule, status, execution_date,
               triggered_by, error_message, created_at
        FROM airflow_pipeline_runs
        ORDER BY created_at DESC
        LIMIT %s
    """
    return query(sql, [limit])


def fetch_dag_logs(pipeline_id: str = None, dag_run_id: str = None, limit: int = 200) -> list[dict]:
    logger.info("fetch_dag_logs(pipeline_id=%s, dag_run_id=%s, limit=%d)", pipeline_id, dag_run_id, limit)
    conditions = []
    params = []

    if pipeline_id:
        conditions.append("pipeline_id = %s")
        params.append(pipeline_id)
    if dag_run_id:
        conditions.append("dag_run_id = %s")
        params.append(dag_run_id)

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    params.append(limit)

    sql = f"""
        SELECT id, pipeline_id, dag_run_id, task_id,
               status, log_content, log_file_path, created_at
        FROM pipeline_dag_logs
        {where}
        ORDER BY created_at DESC
        LIMIT %s
    """
    return query(sql, params)


def fetch_full_pipeline_summary(pipeline_name: str) -> dict:
    logger.info("fetch_full_pipeline_summary(pipeline=%s)", pipeline_name)
    return {
        "pipeline_name": pipeline_name,
        "runs": fetch_pipeline_runs(pipeline_name),
        "logs": fetch_pipeline_logs(),
        "metrics": fetch_pipeline_metrics(pipeline_name),
        "airflow_runs": fetch_airflow_runs(pipeline_name),
        "dag_logs": fetch_dag_logs(),
    }


def _resolve_dataset_path(path: str) -> str:
    """
    The frontend may submit a relative path like 'Dataset/foo.csv' or just
    'foo.csv'. Inside the container the file lives under one of several
    mounted roots (/app/dataset, /app/data, /app/uploads, /opt/airflow/dataset_win).
    Try the path as-is first, then fall back to those roots with case-insensitive
    matching so dataset filenames work regardless of how the user typed them.
    """
    import os, glob

    if not path:
        return path

    # 1) Exact path (absolute or relative to CWD).
    if os.path.exists(path):
        return path

    # 2) Strip any leading "Dataset/" / "dataset/" / "data/" prefix and try roots.
    cleaned = path.replace("\\", "/").lstrip("./")
    parts = cleaned.split("/", 1)
    tail  = parts[1] if len(parts) > 1 and parts[0].lower() in {"dataset", "data", "uploads"} else cleaned

    roots = [
        "/app/dataset", "/app/data", "/app/uploads",
        "/opt/airflow/dataset_win", "/opt/airflow/dataset",
        "Dataset", "dataset", "data", ".",
    ]
    for root in roots:
        cand = os.path.join(root, tail)
        if os.path.exists(cand):
            return cand
        # case-insensitive lookup inside the root
        if os.path.isdir(root):
            target = os.path.basename(tail).lower()
            for entry in os.listdir(root):
                if entry.lower() == target:
                    return os.path.join(root, entry)

    # 3) Last resort: glob anywhere under /app for the bare filename.
    matches = glob.glob(f"/app/**/{os.path.basename(path)}", recursive=True)
    if matches:
        return matches[0]

    # Nothing found — return original so the caller's error message stays clear.
    return path


def _read_dataframe(path: str) -> pd.DataFrame:
    resolved = _resolve_dataset_path(path)
    if resolved != path:
        logger.info("Resolved dataset path: %r → %r", path, resolved)
    lower = resolved.lower()
    if lower.endswith(".csv"):
        return pd.read_csv(resolved)
    if lower.endswith((".xlsx", ".xls")):
        return pd.read_excel(resolved)
    if lower.endswith(".json"):
        return pd.read_json(resolved)
    if lower.endswith(".parquet"):
        return pd.read_parquet(resolved)
    return pd.read_csv(resolved)

import re

def fetch_table_data(table_name: str, limit: int = 5000) -> list[dict]:
    """Fetch actual rows from a pipeline's target Postgres table for analysis."""
    logger.info("fetch_table_data(table=%s, limit=%d)", table_name, limit)

    if not table_name or not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', table_name):
        logger.error("Invalid or missing table_name: %r", table_name)
        return []

    sql = f'SELECT * FROM "{table_name}" LIMIT %s'
    return query(sql, [limit])

def fetch_table_data_direct(host: str, port: str, database: str,
                             user: str, password: str,
                             table_name: str = None, sql_query: str = None,
                             limit: int = 5000) -> list[dict]:
    """Fetch rows from an EXTERNAL Postgres connection (the one the user
    actually picked in the Connections dropdown) — NOT the internal
    agent/db.py database used for pipeline ingestion bookkeeping."""
    if not sql_query:
        if not table_name or not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', table_name):
            logger.error("Invalid or missing table_name: %r", table_name)
            return []
        sql_query = f'SELECT * FROM "{table_name}" LIMIT %s'
        params = [limit]
    else:
        params = []

    logger.info("fetch_table_data_direct(host=%s, db=%s, table=%s)", host, database, table_name)
    conn = None
    try:
        conn = psycopg2.connect(
            host=host, port=int(port or 5432), dbname=database,
            user=user, password=password, connect_timeout=10,
        )
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(sql_query, params)
            rows = [dict(r) for r in cur.fetchall()]
        logger.info("fetch_table_data_direct → %d rows", len(rows))
        return rows
    except Exception as e:
        logger.error("fetch_table_data_direct failed: %s", e, exc_info=True)
        raise
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

def _normalize_ident(ident: str) -> str:
    ident = (ident or "").strip()
    if ident.startswith('"') and ident.endswith('"'):
        return ident
    return ident.upper()

def fetch_snowflake_table(account: str, user: str, password: str, warehouse: str,
                           database: str, schema: str = "PUBLIC",
                           table: str = None, query: str = None,
                           role: str = None, limit: int = 5000) -> list[dict]:
    """Fetch rows from Snowflake — either a raw query or a table (wrapped in a LIMIT)."""
    logger.info("fetch_snowflake_table(database=%s, schema=%s, table=%s)", database, schema, table)
    try:
        import snowflake.connector
    except ImportError:
        logger.error("snowflake-connector-python not installed")
        raise RuntimeError("snowflake-connector-python not installed. Run: pip install snowflake-connector-python")

    if not query:
        if not table:
            raise ValueError("Either 'query' or 'table' must be provided for snowflake source")
        query = (
            f'SELECT * FROM "{_normalize_ident(database)}".'
            f'"{_normalize_ident(schema)}"."{_normalize_ident(table)}" LIMIT {limit}'
        )

    conn_params = {
        "account": account, "user": user, "password": password,
        "warehouse": warehouse, "database": database, "schema": schema,
        "login_timeout": 10, "network_timeout": 15,
    }
    if role:
        conn_params["role"] = role

    conn = None
    try:
        conn = snowflake.connector.connect(**conn_params)
        cur = conn.cursor(snowflake.connector.DictCursor)
        cur.execute(query)
        rows = cur.fetchall()
        cur.close()
        logger.info("fetch_snowflake_table → %d rows", len(rows))
        return [dict(r) for r in rows]
    except Exception as e:
        logger.error("fetch_snowflake_table failed: %s", e, exc_info=True)
        raise
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def fetch_data_by_source(source_type, **kwargs) -> list[dict]:
    logger.info("fetch_data_by_source(source=%s)", source_type)
    logger.debug("Source kwargs: %s", kwargs)

    try:
        if source_type == "postgres":
            table_name = kwargs.get("table_name")
            logger.info("Reading Postgres table: %s", table_name)
            if not table_name:
                logger.error("postgres source requires table_name")
                return []
            return fetch_table_data(table_name)
        # if source_type == "postgres":
        #     return fetch_pipeline_metrics(kwargs.get("pipeline_name"), kwargs.get("table_name"))

        if source_type == "csv":
            path = kwargs.get("file_path")
            logger.info("Reading CSV: %s", path)
            return _read_dataframe(path).to_dict(orient="records")

        if source_type == "excel":
            path = kwargs.get("file_path")
            logger.info("Reading Excel: %s", path)
            return _read_dataframe(path).to_dict(orient="records")

        if source_type == "google_sheet":
            url = kwargs.get("sheet_url")
            logger.info("Reading Google Sheet: %s", url)
            return pd.read_csv(url).to_dict(orient="records")

        if source_type == "s3":
            s3_path = kwargs.get("s3_path")
            logger.info("Reading S3/path data: %s", s3_path)
            if not s3_path:
                return []
            return _read_dataframe(s3_path).to_dict(orient="records")
        if source_type == "snowflake":
            logger.info("Reading Snowflake data: db=%s table=%s", kwargs.get("sf_database"), kwargs.get("sf_table"))
            return fetch_snowflake_table(
                account   = kwargs.get("sf_account"),
                user      = kwargs.get("sf_user"),
                password  = kwargs.get("sf_password"),
                warehouse = kwargs.get("sf_warehouse"),
                database  = kwargs.get("sf_database"),
                schema    = kwargs.get("sf_schema") or "PUBLIC",
                table     = kwargs.get("sf_table"),
                query     = kwargs.get("sf_query"),
                role      = kwargs.get("sf_role"),
            )

            # logger.error("Unsupported source type: %s", source_type)
            # return []

        if source_type == "api":
            import requests
            api_url = kwargs.get("api_url")
            api_headers = kwargs.get("api_headers") or {}
            logger.info("Fetching API data from: %s", api_url)
            payload = requests.get(api_url, headers=api_headers, timeout=30).json()
            if isinstance(payload, list):
                return payload
            if isinstance(payload, dict):
                for value in payload.values():
                    if isinstance(value, list):
                        return value
                return [payload]
            return []

        logger.error("Unsupported source type: %s", source_type)
        return []

    except Exception as e:
        logger.error("fetch_data_by_source failed for '%s': %s", source_type, e, exc_info=True)
        raise
