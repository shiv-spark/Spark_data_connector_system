
import { FormEvent, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2, UserPlus } from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export const UserManagement = () => {
  const qc = useQueryClient();
  const users = useQuery({
    queryKey: ["users"],
    queryFn: async () => (await api.get("/auth/users")).data,
  });

  const updateRole = useMutation({
    mutationFn: ({ id, role }: { id: number; role: string }) =>
      api.patch(`/auth/users/${id}/role?role=${role}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });

  const deactivate = useMutation({
    mutationFn: (id: number) => api.patch(`/auth/users/${id}/deactivate`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });

  const activate = useMutation({
    mutationFn: (id: number) => api.patch(`/auth/users/${id}/activate`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });

  // ── Add User form state ──────────────────────────────────────────────
  const [newUsername, setNewUsername] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState("viewer");
  const [formError, setFormError] = useState("");

  const createUser = useMutation({
    mutationFn: () =>
      api.post("/auth/register", {
        username: newUsername,
        email: newEmail,
        password: newPassword,
        role: newRole,
      }),
    onSuccess: () => {
      setNewUsername("");
      setNewEmail("");
      setNewPassword("");
      setNewRole("viewer");
      setFormError("");
      qc.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (err: any) => {
      setFormError(err.response?.data?.detail || "Failed to create user");
    },
  });

  const submitNewUser = (e: FormEvent) => {
    e.preventDefault();
    setFormError("");
    createUser.mutate();
  };

  return (
    <div className="space-y-5">
      <Card>
        <CardHeader><CardTitle>Add New User</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={submitNewUser} className="grid grid-cols-1 gap-3 md:grid-cols-5 md:items-end">
            <label className="space-y-1 text-sm font-medium md:col-span-1">
              Username
              <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} required />
            </label>
            <label className="space-y-1 text-sm font-medium md:col-span-1">
              Email
              <Input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} required />
            </label>
            <label className="space-y-1 text-sm font-medium md:col-span-1">
              Password
              <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={6} />
            </label>
            <label className="space-y-1 text-sm font-medium md:col-span-1">
              Role
              <select
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={newRole}
                onChange={(e) => setNewRole(e.target.value)}
              >
                <option value="admin">admin</option>
                <option value="editor">editor</option>
                <option value="viewer">viewer</option>
              </select>
            </label>
            <Button type="submit" disabled={createUser.isPending} className="md:col-span-1">
              {createUser.isPending ? <Loader2 className="animate-spin" /> : <UserPlus />} Add User
            </Button>
          </form>
          {formError && <p className="mt-2 text-sm text-red-500">{formError}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>User Management</CardTitle></CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left">
                <th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {(users.data ?? []).map((u: any) => (
                <tr key={u.id} className="border-t">
                  <td>{u.username}</td>
                  <td>{u.email}</td>
                  <td>
                    <select
                      value={u.role}
                      onChange={(e) => updateRole.mutate({ id: u.id, role: e.target.value })}
                    >
                      <option value="admin">admin</option>
                      <option value="editor">editor</option>
                      <option value="viewer">viewer</option>
                    </select>
                  </td>
                  <td>{u.is_active ? "Active" : "Deactivated"}</td>
                  <td>
                    {u.is_active ? (
                      <Button variant="outline" size="sm" onClick={() => deactivate.mutate(u.id)}>
                        Deactivate
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" onClick={() => activate.mutate(u.id)}>
                        Activate
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};
